local function fluid(n)
 local t=table.deepcopy(data.raw.fluid.water);t.name=n;t.localised_name=n;t.max_temperature=400;data:extend{t}
end
fluid("triage-coolant");fluid("triage-used-coolant")
local function f(n,a,t,low,high) return {type="fluid",name=n,amount=a,temperature=t,minimum_temperature=low,maximum_temperature=high} end
local function i(n,a) return {type="item",name=n,amount=a} end
local function recipe(n,ins,outs)
 data:extend{{type="recipe",name=n,localised_name=n,categories={"chemistry"},ingredients=ins,results=outs,enabled=true,energy_required=1,main_product=outs[1].name,auto_recycle=false}}
end
local cold,used="triage-coolant","triage-used-coolant"
recipe("triage-cast",{f(cold,10,nil,nil,50),i("iron-ore",1)},{i("iron-plate",1),f(used,10,300)})
recipe("triage-restore",{f(used,100,nil,nil,50)},{f(cold,80,25)})
for _,v in ipairs{{250,350,200,175},{150,250,100,150},{50,150,25,125}} do
 recipe("triage-cool-"..v[1],{f(used,100,nil,v[1],v[2])},{f(used,100,v[3]),f("steam",25,v[4])})
end
local silo=table.deepcopy(data.raw["rocket-silo"]["rocket-silo"])
silo.name="triage-selectable-silo";silo.localised_name="Selectable rocket silo";silo.fixed_recipe=nil;silo.minable.result=silo.name
local item=table.deepcopy(data.raw.item["rocket-silo"]);item.name=silo.name;item.localised_name=silo.localised_name;item.place_result=silo.name
local variant=table.deepcopy(data.raw.recipe["rocket-part"]);variant.name="triage-alternate-rocket-part";variant.localised_name="Alternate rocket part";variant.enabled=true;variant.ingredients={i("copper-plate",1)}
data:extend{silo,item,variant}
recipe("triage-use-steam",{f("steam",10)},{i("stone-brick",1)})
for _,t in ipairs({125,150,175}) do recipe("triage-steam-"..t,{i("stone",1)},{f("steam",10,t)}) end
