local function recipe(name, label, category, ingredients, results, main)
  data:extend{{type="recipe", name=name, localised_name=label, categories={category}, enabled=true, energy_required=1, ingredients=ingredients, results=results, main_product=main, allow_productivity=true, auto_recycle=false}}
end
local function item(name, amount)
  return {type="item",name=name,amount=amount}
end
recipe("triage-return","Split coal return","crafting",{item("coal",1)},{
  {type="item",name="stone",amount=1,ignored_by_productivity=1},
  {type="item",name="coal",amount=1,independent_probability=.15},
  {type="item",name="coal",amount=1,independent_probability=.15,ignored_by_productivity=1}},"stone")
local fuel=table.deepcopy(data.raw.item.coal)
fuel.name="triage-coal"; fuel.localised_name="Coal with iron residue"; fuel.burnt_result="iron-plate"; fuel.fuel_value="4MJ"
data:extend{fuel}
local function copyMachine(kind, original, name, label)
  local machine=table.deepcopy(data.raw[kind][original])
  local place=table.deepcopy(data.raw.item[original])
  machine.name=name; machine.localised_name=label; machine.minable.result=name
  place.name=name; place.place_result=name; place.localised_name=label
  data:extend{machine,place}
  return machine
end
local fixed=copyMachine("assembling-machine","assembling-machine-2","triage-cable-machine","Cable-only assembler")
fixed.fixed_recipe="copper-cable"
local pump=copyMachine("offshore-pump","offshore-pump","triage-acid-pump","Acid-only offshore pump")
pump.fluid_box.filter="sulfuric-acid"
recipe("triage-hot-water","Warm water supply","chemistry",{item("stone",1)},{{type="fluid",name="water",temperature=100,amount=100}},"water")
recipe("triage-steam165","Steam supply (165 C)","chemistry",{item("stone",1)},{{type="fluid",name="steam",temperature=165,amount=10}},"steam")
recipe("triage-steam-use","Use warm steam","chemistry",{{type="fluid",name="steam",minimum_temperature=100,maximum_temperature=200,amount=10}},{item("stone-brick",1)},"stone-brick")
local smelter=copyMachine("furnace","stone-furnace","triage-residue-furnace","Residue furnace")
smelter.energy_source.burnt_inventory_size=1
recipe("triage-coal-smelting","Produce coal","smelting",{item("stone",1)},{item("coal",5)},"coal")
