local m=table.deepcopy(data.raw["fusion-generator"]["fusion-generator"])
m.name="muluna-cycling-steam-turbine";m.localised_name="Recycling steam turbine";m.minable.result=m.name
m.energy_source.output_flow_limit="9MW";m.max_fluid_usage=1.5;m.input_fluid_box.filter="steam";m.minimum_input_temperature=165;m.maximum_temperature=500
m.output_fluid_box.filter="water";m.output_fluid_box.temperature=100
local i=table.deepcopy(data.raw.item["fusion-generator"]);i.name=m.name;i.localised_name=m.localised_name;i.place_result=m.name
data:extend{m,i}
